var switch_place = document.querySelector('.main_img');

function switch_img(link) {
    switch_place.src = link;
}



