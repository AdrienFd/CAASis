<?php

dump(Auth::check());
dump(session()->all());

?>