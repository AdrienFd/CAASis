Bonjour {{ $name }}<br><br>
activez votre compte en cliquant sur le lien :<br><br>

{{ url('user/activation', $link )}}