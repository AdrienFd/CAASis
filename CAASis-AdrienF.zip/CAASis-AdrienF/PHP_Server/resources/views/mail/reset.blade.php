Voici votre nouveau mot de passe nous vous invitons à la changer dès votre connection avec celui ci :<br><br>

{{ $password }}