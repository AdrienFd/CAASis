# CAASis
CAASis is a Web Project using HTML/CSS/JS/PHP/Node.JS/SQL. The purpose is to design a Website for the students office, where students can give event ideas and vote for these, they can also command items from the students office, the purchase part is optional.
