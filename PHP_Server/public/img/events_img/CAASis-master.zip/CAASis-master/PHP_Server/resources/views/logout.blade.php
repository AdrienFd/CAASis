<?php
Auth::logout();
return view('index');
?>