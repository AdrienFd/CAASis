<div class="header">
    <img src="/img/logo.png" />
</div>

<!-- Nav button -->
<button href="#navPanel" class="menu_button">&#x2630</button>

@include('includes.navbar')