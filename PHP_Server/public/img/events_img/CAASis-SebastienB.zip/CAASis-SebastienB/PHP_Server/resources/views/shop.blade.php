@extends('layout')


@section('content')

<div class="section">
    Article 1
    delectus veniam expedita, possimus ad eius exercitationem voluptates numquam molestiae, quae, a sit cupiditate.
    Lorem ipsum dolor sit amet consectetur adipisicing elit. Et accusamus hic, nobis nihil dicta error? Similique porro
    recusandae officia velit aliquid blanditiis dignissimos non facilis minima. Rerum assumenda distinctio eius?
    Lorem ipsum dolor sit amet consectetur adipisicing elit. Natus magni quis maiores distinctio eligendi quos pariatur
    laborum necessitatibus quas sapiente ea, sed in vitae. Numquam aperiam provident laudantium molestiae mollitia!
</div>

<div class="section">
    Article 2
    delectus veniam expedita, possimus ad eius exercitationem voluptates numquam molestiae, quae, a sit cupiditate.
    Lorem ipsum dolor sit amet consectetur adipisicing elit. Et accusamus hic, nobis nihil dicta error? Similique porro
    recusandae officia velit aliquid blanditiis dignissimos non facilis minima. Rerum assumenda distinctio eius?
    Lorem ipsum dolor sit amet consectetur adipisicing elit. Natus magni quis maiores distinctio eligendi quos pariatur
    laborum necessitatibus quas sapiente ea, sed in vitae. Numquam aperiam provident laudantium molestiae mollitia!
</div>
@endsection