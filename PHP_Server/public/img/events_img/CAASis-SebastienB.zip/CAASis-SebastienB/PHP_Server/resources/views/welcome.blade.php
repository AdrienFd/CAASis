@extends('layout')


@section('content')
<div class="title m-b-md">
    Laravel
</div>
@endsection
