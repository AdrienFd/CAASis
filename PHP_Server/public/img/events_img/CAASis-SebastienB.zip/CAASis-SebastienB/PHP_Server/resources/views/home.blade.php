@extends('layout')


@section('content')
<h1>BDE's Website</h1>

<section>

    <div id="background_img">
        <img id="background_image" src="/img/background_img1.jpg">
    </div>

    <div id="article_left">
        <p>Lorem ipsum efp;ef,ezkf,zkfl,fkkfkrkgkkf,ekfker,frogkt
            Lorem ipsum efp;ef,ezkf,zkfl,fkkfkrkgkkf,ekfker,frogkteo
        </p>
    </div>


</section>
@endsection
