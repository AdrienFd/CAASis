<h1>Bonjour <?php echo $prenom ?></h1>
